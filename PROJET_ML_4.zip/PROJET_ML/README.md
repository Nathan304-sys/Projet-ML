Dans ce projet la version de python utilisée est le python 3.8 
Pour lancer le projet il faut:
- avoir conda installé autorisant l'accès aux variables d'environnement
- Créer un environnement conda avec python 3.8 avec le prompt de anaconda en tapant conda create --name *nomdel'environnement* puis taper conda activate *nomdel'environnement*.
- Installer les version des  bibliothèques décrites dans le requirements.txt en tapant: pip install requirements.txt
- Exécuter les note-book



